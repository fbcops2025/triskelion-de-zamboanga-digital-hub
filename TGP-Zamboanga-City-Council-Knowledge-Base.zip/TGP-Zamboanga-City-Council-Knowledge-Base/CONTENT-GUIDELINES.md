# Public Website Content & Writing Standard

The public website should feel like a **living institutional website**, not a research paper, case file, or internal database.

## Core writing rule

Every page must answer a real visitor question or satisfy a clear search intent. Research supports the page, but it should not dominate the reading experience.

### Public-facing copy should

- Lead with meaning, relevance, and context.
- Use clear, natural language that a member, family member, student, researcher, community partner, or Zamboanga resident can understand quickly.
- Explain why a date, chapter, project, or person matters instead of simply listing records.
- Use short paragraphs, descriptive headings, timelines, cards, profiles, and contextual links.
- Mention **Tau Gamma Phi**, **Triskelion**, **Zamboanga City**, and relevant chapter/service terms naturally where they help the reader.
- Include source links or verification notes without interrupting the main narrative.
- Use exact dates only when the research supports them.
- Keep the site respectful, historical, civic-minded, and community-oriented.

### Avoid

- Repeating “PRIMARY-SOURCE CLAIM,” “UNVERIFIED,” or similar research terminology throughout the body copy.
- Keyword stuffing.
- Writing pages that read like search-engine bait.
- Publishing speculative chapter histories, officer lists, membership, or event totals.
- Turning every page into a chronology or table.
- Long walls of text when a timeline, card grid, quote, profile, or image caption would communicate better.
- Political-campaign tone or language that endorses public officials.

## How to handle uncertainty publicly

Use natural language such as:

> Council historical materials trace the Zamboanga City Council's local history to 5 December 1975 in Baliwasan Chico. The digital archive is continuing to collect original records, photographs, and documents from this period.

Then place the detailed verification status in a compact **Sources & Record Notes** section at the bottom of the page.

## SEO quality standard

A page is not ready merely because it contains a keyword. It should provide a better answer than a visitor could get from a short Facebook post.

Each indexable page should have:

- One clear primary search intent.
- A unique SEO title.
- A useful meta description.
- One clear H1.
- A strong opening paragraph that answers what the page is about.
- Helpful H2/H3 sections.
- At least two relevant internal links where appropriate.
- Useful media or archive material when rights-cleared.
- A natural next action.
- Source notes when facts depend on historical records.

## Tone

**Dignified, readable, grounded, warm, historical, service-oriented, and locally relevant.**

Not academic. Not aggressive. Not exaggerated. Not generic.
