# Changelog

## 1.0 - Knowledge-base conversion

- Preserved the uploaded research as `MASTER-RESEARCH.md`.
- Split the project into public content, research control, and website-system layers.
- Added human-readable, SEO-intentional drafts for the main public pages.
- Added navigation and internal links.
- Added page frontmatter for future CMS/site generation.
- Kept unverified history, current leadership, contact details, and chapter gaps behind publication gates rather than inventing missing information.
