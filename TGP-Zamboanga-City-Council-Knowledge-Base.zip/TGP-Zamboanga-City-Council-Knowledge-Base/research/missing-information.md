# Information Gaps

## Critical

- Signed or council-approved 2026 officer roster / election result.
- Original or council-certified 1975 establishment record.
- Original or council-certified 1978 WMSU Mother Chapter record.
- Approved chapter directory.
- Official logo file and public usage authorization.
- Canonical post permalinks for major historical claims.
- Verified public contact channel.

## Important

- Past chairmen / city leadership archive.
- Council resolutions and memoranda.
- Chapter charters and founding records.
- Event after-action reports.
- Historical photos with rights and caption data.
- Anniversary programs and commemorative materials.
- Official terminology and role definitions.

## Optional but valuable

- Oral-history interviews with release/consent.
- Old newspaper clippings.
- Commemorative graphics.
- Expanded photo and video archive.
- Metadata enrichment for older records.
