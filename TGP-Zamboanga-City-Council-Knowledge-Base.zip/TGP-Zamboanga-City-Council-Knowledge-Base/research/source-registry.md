# Source Registry

| ID | Source | Use | Notes |
|---|---|---|---|
| SRC-001 | https://www.facebook.com/TGPZCC | Owner-supplied official council channel | Retain original post permalinks for high-impact facts. |
| SRC-002 | Local `TGP Zamboanga City.md` research synthesis | Historical leads and claim mapping | Research aid, not a substitute for original sources. |
| SRC-003 | Olympics / institutional records and House member record referenced in master research | Public biography / public-office context | Does not itself prove TGP membership. |
| SRC-004 | Politiko report on 2021 World Blood Donor Day activity | Curuan Chapter participation | Article images are not automatically reusable. |
| SRC-005 | PTV News and ABS-CBN reports referenced in master research | 2023 prayer rally / vigil | Re-collect final URLs before publication. |
| SRC-006 | Official Gazette RA 11053 | National legal context | Do not treat as proof of local compliance. |
| SRC-007 | Wikimedia Commons contextual images | Geographic/context visuals | Follow license and attribution. |
| SRC-008 | Council officer roster / election result | Current leadership | Critical missing primary record. |
| SRC-009 | Local Tau Gamma Phi historical research packet | National historical context | Review before public use. |
