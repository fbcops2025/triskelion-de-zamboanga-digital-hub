# Verification Matrix

## Strongly verified in the current baseline

- Zamboanga City geographic context.
- Jerry Evangelista Perez public office in the source baseline. This does not by itself prove fraternity membership.
- 2021 public reporting naming Tau Gamma Phi Fraternity - Curuan Chapter among World Blood Donor Day participants.
- Rights information for the identified Wikimedia contextual assets.

## Council historical accounts requiring stronger archival records

- 5 December 1975 establishment in Baliwasan Chico under Bro. Alfredo Granados.
- 8 December 1978 establishment of the WMSU Mother Chapter.
- Several recent leadership, chapter, anniversary, and event references summarized from council material.

## Conflicts / unresolved

- 2024 third-party “50th anniversary” reference versus council 2025 Golden Anniversary cycle.
- Belmar Rojas name variants.
- Final 2026 post-election leadership roster.

## Do not publish as settled fact yet

- Complete chapter count or district map.
- Full founding-member list.
- Complete historical officer chronology.
- Exact founding dates for many chapters.
- Unverified notable-member affiliations.
- Organization-owned logo rights or usage rules.
