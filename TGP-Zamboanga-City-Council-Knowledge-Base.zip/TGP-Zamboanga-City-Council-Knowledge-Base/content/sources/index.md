---
title: "Sources and Verification"
slug: "/sources/"
seo_title: "Sources & Historical Verification | TGP Zamboanga City Council"
meta_description: "See how the Tau Gamma Phi Zamboanga City Council digital archive verifies historical records, handles conflicting information, and preserves source links."
primary_intent: "Sources and verification for TGP Zamboanga history"
status: "ready"
---

# Sources and Historical Verification

The public website is designed to be readable first, but important historical information should still be traceable to a source. This page explains how the archive separates a documented fact from a council account, a credible secondary report, an unresolved lead, or conflicting information.

## Source priority

The strongest historical records are original council or chapter documents, dated resolutions, minutes, charters, signed rosters, contemporaneous photographs with captions, official posts with permanent links, government records, institutional records, and reputable reporting.

Research summaries are useful for finding leads, but they should not replace the underlying source when a stronger original record can be preserved.

## When records disagree

Historical archives sometimes contain different dates, spellings, titles, or anniversary counts. The website should not quietly choose one version and erase the other. The archive records the conflict, keeps the available sources, and updates the public page only when stronger evidence supports a correction.

## Corrections are part of preservation

A correction does not weaken an archive. A documented correction makes the archive more trustworthy. Significant changes should retain a revision note so future researchers can see what changed and why.

[Submit a correction or source](../corrections/index.md)
