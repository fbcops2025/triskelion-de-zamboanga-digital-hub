---
title: "Leadership Archive"
slug: "/leadership/archive/"
seo_title: "Zamboanga City Council Leadership Archive | Tau Gamma Phi"
meta_description: "Explore documented past leadership references of Tau Gamma Phi - Zamboanga City Council, organized by year and source."
primary_intent: "Past leaders of Tau Gamma Phi Zamboanga City Council"
status: "research-backed-draft"
---

# Leadership Archive

The leadership archive preserves publicly documented officer references by year. It is not intended to replace the current council roster, and incomplete years should remain clearly marked until stronger records are recovered.

## 2022

Council material names **Anfernee Jay Fernandez** as City Chairman and **Maverick Bader Sebastian** as Vice City Chairman.

## 2024

Council anniversary material names **Marlon G. Avenido** as City Chairman and **Ferdinand D. Sotto** as Vice-Chairman / Deputy Grand Triskelion.

## 2026 references

Public material reviewed in the research baseline continued to name **Marlon G. Avenido** in a city-chairman role through late September 2026. **Belmar F. Rojas / Belmar Rojas Fabian** appears in a City Vice Chairman role and as a league organizer. The name variant requires confirmation, and the final 2026 post-election roster remains missing.

## Help complete the record

Older officer lists, election results, anniversary programs, signed memoranda, photographs with captions, and council resolutions can help fill the gaps in this archive.

[Contribute an officer record](../corrections/index.md) | [View Sources & Verification](../sources/index.md)
