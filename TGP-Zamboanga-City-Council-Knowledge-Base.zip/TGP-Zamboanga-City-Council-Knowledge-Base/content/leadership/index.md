---
title: "Leadership"
slug: "/leadership/"
seo_title: "Tau Gamma Phi Zamboanga City Council Leadership"
meta_description: "View the public leadership record of Tau Gamma Phi - Zamboanga City Council and learn how officer information is verified before publication."
primary_intent: "Current leadership of Tau Gamma Phi Zamboanga City Council"
status: "pending-current-roster"
---

# Zamboanga City Council Leadership

Leadership records are an important part of preserving council history. This page is intended to show the **current council leadership only after the active roster and term details are formally confirmed for public release**.

## Current leadership

**Publication pending council confirmation.**

The research baseline contains leadership references through September 2026, but the final post-election roster was not recovered. Rather than publish a potentially outdated list as current, the website should wait for a signed or council-approved roster that confirms each officer's name, exact title, term, and approved public photo.

## Why the archive keeps past leadership

Council leadership changes over time, but each administration becomes part of the historical record. The leadership archive is designed to preserve officers by year and term so that future visitors can understand who served, when they served, and which records support that entry.

[View the Leadership Archive](archive.md)

## Publication standard

Each public leadership record should include the officer's name, exact position, term or year, council or chapter context, last-verified date, and an approved source. Photographs should be used only when publication permission is clear.

This approach avoids a common problem on organizational websites: old officers remaining online long after a transition and being mistaken for the current administration.

[Submit a leadership correction or record](../corrections/index.md)
