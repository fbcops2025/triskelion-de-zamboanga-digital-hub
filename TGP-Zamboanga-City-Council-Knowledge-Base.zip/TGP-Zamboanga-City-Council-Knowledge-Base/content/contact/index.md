---
title: "Contact"
slug: "/contact/"
seo_title: "Contact Tau Gamma Phi - Zamboanga City Council"
meta_description: "Find verified public contact channels for Tau Gamma Phi - Zamboanga City Council and learn where to send archive, media, and correction inquiries."
primary_intent: "Contact Tau Gamma Phi Zamboanga City Council"
status: "blocked-until-contact-confirmed"
---

# Contact the Zamboanga City Council

The website should publish only **council-approved public contact channels**. The current research baseline does not yet contain a verified public email address, phone number, or contact form destination for publication.

## Official public page

The project owner supplied the following Facebook page as the council's official public page:

https://www.facebook.com/TGPZCC

Before this page goes live on the website, the council should confirm any additional public email address, phone number, office address, media contact, or archive-submission channel.

## Historical records and corrections

The future contact system should route historical submissions and corrections separately from general inquiries so that evidence can be reviewed and tracked properly.

[Submit a historical correction](../corrections/index.md)
