---
title: "About Tau Gamma Phi - Zamboanga City Council"
slug: "/about/"
seo_title: "About Tau Gamma Phi Zamboanga City Council"
meta_description: "Learn about the public role, history, chapters, service work, and digital archive of Tau Gamma Phi - Zamboanga City Council."
primary_intent: "Learn what the Zamboanga City Council is and what this website provides"
status: "draft-for-council-review"
---

# About the Zamboanga City Council

**Tau Gamma Phi - Zamboanga City Council** is represented in this public project as a local council connected with Tau Gamma Phi and the Triskelion community in Zamboanga City. The website is designed to make approved public information easier to discover while protecting the parts of fraternity life that do not belong in a public archive.

## What this website is for

This is a public information and historical preservation project. It is intended to help people find clear, organized information about the council's history, documented chapters, public leadership records, community service, events, archival materials, and official public channels.

It also gives future officers and chapters a more durable record than social media alone. A Facebook post can document a moment. A structured archive can connect that moment to the people, place, chapter, year, source, and larger history around it.

## What belongs on the public website

The site may publish council-approved history, chapter profiles, public leadership roles and terms, event notices and recaps, community-service records, public documents, rights-cleared photographs, and source-backed historical materials.

Private member rosters, initiation or ritual material, private contact details, confidential complaints, sensitive beneficiary information, security details, and unverified allegations do not belong on the public site.

## History with context

Council historical materials trace the local story to **5 December 1975 in Baliwasan Chico**, with **8 December 1978** recorded as an important date for the WMSU Mother Chapter. Rather than treating these dates as isolated facts, the archive will connect them to documents, people, chapter records, photographs, and later milestones as stronger source material becomes available.

[Read the history](../history/index.md)

## Service as a public record

The council and its documented chapters have appeared in public records connected with civic and community activities. This site treats service as more than a gallery of event photos. Each public record should explain what the activity was, where it happened, when it happened, which partners or chapters were involved, and what evidence supports the entry.

[Explore community service](../service/index.md)

## Built for continuity

The long-term goal is simple: make the public history easier to preserve, easier to verify, and easier for the next generation to continue. That means organized chapter records, leadership archives, timelines, source links, correction history, and a contribution process for people who hold older materials.

[Browse the digital archive](../archive/index.md)
