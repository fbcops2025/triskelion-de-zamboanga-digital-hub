---
title: "Tau Gamma Phi - Zamboanga City Council"
slug: "/"
seo_title: "Tau Gamma Phi Zamboanga City Council | History, Chapters & Service"
meta_description: "Explore the public history, chapters, community service, events, and digital archive of Tau Gamma Phi - Zamboanga City Council in Zamboanga City."
primary_intent: "Official/public information about Tau Gamma Phi Zamboanga City Council"
status: "draft-for-council-review"
---

# Tau Gamma Phi - Zamboanga City Council

## Brotherhood, history, and service in Zamboanga City

This website is being built as a public home for the history, community work, chapters, events, and archival records connected with **Tau Gamma Phi - Zamboanga City Council**. It brings together information that is often scattered across social media posts, old photographs, chapter records, event materials, and personal collections so that important parts of the council's story are easier to find, understand, and preserve.

[Explore the history](history/index.md) | [Browse chapters](chapters/index.md)

## A local story worth preserving

Council historical materials trace the Zamboanga City Council's local history to **5 December 1975 in Baliwasan Chico**. Another important milestone in the council record is the establishment of the **WMSU Mother Chapter on 8 December 1978**. These early records form part of a larger history that the digital archive is continuing to document with original materials and community contributions.

The goal is not simply to collect dates. It is to preserve the people, chapters, public activities, service projects, milestones, and memories that show how the Triskelion community developed in Zamboanga City over time.

[Read the Zamboanga City Council history](history/index.md)

## Service beyond the fraternity

Public records connected with the council and its chapters include blood-donation participation, food-pack repacking, feeding activities, community visitation, environmental activities, sports programs, and other civic initiatives.

The service archive focuses on what can be documented responsibly: what happened, when and where it happened, who organized or partnered in the activity, and what source supports the public record.

[See community service records](service/index.md)

## Chapters and communities

The Zamboanga City Council story is also the story of its chapters and local communities. This website will gradually build an approved chapter directory containing histories, founding records, public officers where appropriate, milestones, service activities, and archival materials.

Current research includes documented references to the **WMSU Mother Chapter, Lunzuran Chapter, Triskelion de Zambowood, Sibulao Chapter**, and other chapter or community names that still require formal registry confirmation.

[Explore documented chapters](chapters/index.md)

## A digital archive built to last

Old photographs, anniversary materials, certificates, public memoranda, event programs, news coverage, and chapter records can lose context when they remain scattered across personal accounts or social-media feeds. The archive is designed to preserve that context by recording dates, captions, source information, ownership or permission, and the historical significance of each item.

[Visit the digital archive](archive/index.md)

## Help strengthen the historical record

If you have an original photograph, chapter document, anniversary program, officer record, event material, or correction that can improve the public history, the project can accept it for review. Submissions are not automatically published. They are checked, attributed, and reviewed before becoming part of the public archive.

[Contribute a historical record](corrections/index.md)

### Sources & record notes

The 1975 and 1978 dates above come from council historical material summarized in the project research baseline. Original founding records are still being sought for archival confirmation. See [Sources & Verification](sources/index.md) for the publication method.
