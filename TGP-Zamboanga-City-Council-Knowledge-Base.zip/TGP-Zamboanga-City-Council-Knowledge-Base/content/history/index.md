---
title: "History of Tau Gamma Phi - Zamboanga City Council"
slug: "/history/"
seo_title: "Tau Gamma Phi Zamboanga History | Zamboanga City Council"
meta_description: "Explore the documented history and milestones of Tau Gamma Phi - Zamboanga City Council, from its 1975 historical account to later chapters, service, and events."
primary_intent: "History of Tau Gamma Phi in Zamboanga City"
status: "draft-for-council-review"
---

# The History of Tau Gamma Phi in Zamboanga City

The story of Tau Gamma Phi in Zamboanga City is spread across decades of chapter activity, council leadership, public service, anniversaries, photographs, event materials, and personal memory. This page brings those pieces together into a readable public history while the deeper archive preserves the sources behind them.

## The 1975 Zamboanga City Council account

Council historical materials trace the formal establishment of the **Zamboanga City Council to 5 December 1975 in Baliwasan Chico**, under **Bro. Alfredo Granados**. This date is central to the council's own historical narrative and to the Golden Anniversary cycle associated with 2025.

The archive is still seeking original 1975 records such as minutes, charter documents, dated photographs, official correspondence, or certified historical accounts. Until those materials are recovered, the website should describe 1975 as the council's documented historical account rather than presenting missing archival details as settled fact.

## The WMSU Mother Chapter milestone

Council material records **8 December 1978** as the establishment date of the **WMSU Mother Chapter** at Western Mindanao State University. The chapter is an important part of the local historical narrative, but its original charter, founding-officer list, and early records still need to be added to the archive.

[View the WMSU Mother Chapter record](../chapters/wmsu-mother-chapter.md)

## From scattered records to a connected history

Later records show a growing public trail of council and chapter activity. These include leadership references, anniversaries, sports and community events, blood-donation participation, feeding programs, environmental activities, public vigils, and other civic engagements.

Instead of publishing a long list of dates with no context, the website organizes history around meaningful periods and milestones. Visitors can move from a timeline entry to the chapter, person, event, project, photograph, or source connected to it.

[Explore the historical timeline](timeline.md)

## The Golden Anniversary period

Council material treats **2025 as the Golden or 50th anniversary year**, which aligns with the 1975 historical account. A separate third-party reference reportedly used 2024 as a 50th anniversary marker, so the archive retains that conflict until stronger original documentation is collected.

For public storytelling, the council's own anniversary material should be presented with its source and date rather than silently rewriting conflicting records.

## Why the archive matters

A history this long cannot depend on one social-media page, one officer, or one private photo collection. The digital archive is intended to preserve records with enough context that future members and researchers can still understand what they are looking at years from now.

That means every strong historical entry should eventually connect to an original or approved source, a date, a caption, and where possible, the people and chapter involved.

[Contribute a historical record](../corrections/index.md)

### Sources & record notes

The 1975 and 1978 dates are currently preserved as council historical accounts in the research baseline. Original founding documentation remains a priority for the archive. See [Sources & Verification](../sources/index.md).
