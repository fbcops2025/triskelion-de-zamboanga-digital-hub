---
title: "Zamboanga City Council Historical Timeline"
slug: "/history/timeline/"
seo_title: "Tau Gamma Phi Zamboanga Timeline | Zamboanga City Council"
meta_description: "Follow key documented milestones in the public history of Tau Gamma Phi - Zamboanga City Council, from the 1970s to recent community activities."
primary_intent: "Timeline of Tau Gamma Phi Zamboanga City Council"
status: "draft-for-council-review"
---

# Historical Timeline

This timeline highlights public milestones currently supported by the research baseline. It is designed to grow as older records, chapter documents, photographs, and council materials are recovered.

## 1975

**5 December 1975** - Council historical material traces the formal establishment of the Zamboanga City Council to Baliwasan Chico under Bro. Alfredo Granados.

## 1978

**8 December 1978** - Council historical material records the establishment of the WMSU Mother Chapter at Western Mindanao State University.

## 2016

The current research dossier identifies 2016 as the earliest dated artifact recovered from the council's public-page trail. The exact item and permalink should be preserved in the archive before it is featured publicly.

## 2021

A World Blood Donor Day activity in Zamboanga City was publicly reported with **Tau Gamma Phi Fraternity - Curuan Chapter** named among participating donor groups.

## 2022

Council material identifies **Anfernee Jay Fernandez** as City Chairman and **Maverick Bader Sebastian** as Vice City Chairman during this period. Public activities referenced in the record include Hermosa Festival participation and food-pack repacking connected with the City Government/CSWD.

## 2023

Tau Gamma Phi / Tau Gamma Sigma participants in Zamboanga held a public prayer rally and candlelight vigil following the death of Adamson student John Matthew Salilig. The event was covered by Philippine news organizations and is one of the stronger independently reported items in the current archive.

## 2024

Council anniversary material names **Marlon G. Avenido** as City Chairman and **Ferdinand D. Sotto** as Vice-Chairman / Deputy Grand Triskelion. Records also refer to national-anniversary representation and a Zamboanga Grand Motorcade.

## 2025

Council material treats 2025 as the **Golden Anniversary** year of the Zamboanga City Council, consistent with the 1975 historical account.

## 2026

The public record includes an election process, the Triskelion Basketball League, a Zambowood feeding activity, a Philippine Red Cross blood-drive announcement, a Zamboanga City Jail visitation, environmental and coastal activity, the opening of Sibulao Chapter, and Fiesta y Juego at Sta. Maria Elementary School.

The archive should distinguish between an **announced activity** and a **completed activity with verified outcomes**. Attendance figures, beneficiary counts, election results, and similar details should only be published when a source directly confirms them.

[Back to History](index.md) | [Browse Events](../events/index.md)
