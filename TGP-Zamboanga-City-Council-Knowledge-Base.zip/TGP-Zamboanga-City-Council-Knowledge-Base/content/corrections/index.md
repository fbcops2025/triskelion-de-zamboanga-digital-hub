---
title: "Corrections and Historical Contributions"
slug: "/corrections/"
seo_title: "Submit a Tau Gamma Phi Zamboanga Historical Record or Correction"
meta_description: "Contribute a historical document, photo, chapter record, event source, or correction to the Tau Gamma Phi Zamboanga City Council digital archive."
primary_intent: "Submit records or corrections to the TGP Zamboanga archive"
status: "workflow-ready"
---

# Help Strengthen the Historical Record

The archive is designed to improve over time. Members, former officers, chapter representatives, families, community partners, and researchers may hold records that can fill important gaps in the public history.

## Useful contributions

Helpful materials include original or scanned council documents, chapter charters, old officer lists, anniversary programs, dated photographs, certificates, event programs, public memoranda, newspaper clippings, official social-media post links, and corrections supported by evidence.

## What to include with a submission

Whenever possible, provide the date or approximate year, people or chapter involved, where the item came from, who owns it, whether it may be published, and why it is relevant.

## Review before publication

A submission is not automatically published. It enters a review queue where the source, context, rights, duplicates, and conflicts can be checked. Sensitive or private information should be removed before a record is made public.

## Corrections

If you believe a page contains an incorrect name, date, position, chapter, caption, or historical statement, submit the corrected information together with the strongest source you have. The archive should preserve a correction history for important changes.

[Read Sources & Verification](../sources/index.md)
