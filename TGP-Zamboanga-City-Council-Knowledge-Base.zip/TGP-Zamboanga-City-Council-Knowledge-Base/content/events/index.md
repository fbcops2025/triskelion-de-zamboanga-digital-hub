---
title: "Events"
slug: "/events/"
seo_title: "Tau Gamma Phi Zamboanga Events | Zamboanga City Council"
meta_description: "Browse documented Tau Gamma Phi Zamboanga City Council anniversaries, sports events, civic gatherings, public notices, and community activities."
primary_intent: "Tau Gamma Phi events in Zamboanga City"
status: "research-backed-draft"
---

# Events and Public Activities

This archive brings together public events connected with the Zamboanga City Council and documented chapters. Upcoming notices and historical event records should be clearly separated so visitors can immediately tell whether they are looking at a future activity or an archive entry.

## Selected documented events

### Hermosa Festival / Parade of Lights, 2022
Council material records participation connected with Zamboanga City's Hermosa Festival period.

### Prayer Rally and Candlelight Vigil, March 2023
Tau Gamma Phi / Tau Gamma Sigma participants in Zamboanga held a public prayer rally and candlelight vigil following the death of Adamson student John Matthew Salilig. The occurrence was covered by Philippine news organizations.

### ZCC Golden Anniversary cycle, 2025
Council material treated 2025 as the Golden Anniversary year, consistent with the local 1975 historical account.

### Triskelion Basketball League, 25-27 August 2026
Council material records a basketball league at the Canelar Moret Covered Court. Sports events can be preserved with schedules, participating teams, organizers, approved photos, results, and source material, while avoiding assumptions that every team label represents a formally chartered chapter.

### Fiesta y Juego, 27 September 2026
Council material references Fiesta y Juego at Sta. Maria Elementary School as part of the public activity record.

## For current event information

Only council-approved notices with a verified date, venue, organizer, and public contact should appear as “upcoming.” Expired notices should automatically move into the archive rather than remain on the homepage.

[Explore Community Service](../service/index.md) | [View the Historical Timeline](../history/timeline.md)
