---
title: "Chapters"
slug: "/chapters/"
seo_title: "Tau Gamma Phi Chapters in Zamboanga City | ZCC Directory"
meta_description: "Explore documented Tau Gamma Phi chapters and Triskelion communities connected with Zamboanga City Council, with history and record status where available."
primary_intent: "Tau Gamma Phi chapters in Zamboanga City"
status: "research-backed-draft"
---

# Chapters and Triskelion Communities in Zamboanga City

The Zamboanga City Council's history is built through its chapters, schools, neighborhoods, and local communities. This directory is being developed as a **verified public chapter registry**, not simply a list of every name that has appeared in an event poster or sports bracket.

## Documented chapter records

### WMSU Mother Chapter
Council historical material records **8 December 1978** as the chapter's establishment date at Western Mindanao State University. Its charter, founding officers, and complete early history are still being collected.

[View WMSU Mother Chapter](wmsu-mother-chapter.md)

### Lunzuran Chapter
The council has publicly connected Lunzuran Chapter with boxer Eumir Marcial. The chapter's charter, founding date, and current leadership still need to be added to the archive.

[View Lunzuran Chapter](lunzuran.md)

### Triskelion de Zambowood
Council material references Triskelion de Zambowood in connection with a September 2026 feeding activity. The public chapter profile is being built from approved records.

[View Triskelion de Zambowood](zambowood.md)

### Sibulao Chapter
Council material describes Sibulao as a newly opened chapter in 2026 and names Ali Maruji as chairman during that period. The opening or charter document is still needed for the historical archive.

[View Sibulao Chapter](sibulao.md)

## Other documented names

Additional names appear in council material, including Triskelion de Wesmincom, Armor Village, Morning Breeze, Culianan, Southcom, Canelar Moret, Estrada, Main Road Divisoria, Universidad de Zamboanga, Gen. Tinio, and Gen. Concepcion. Some still need formal confirmation of chapter status, founding date, district, and current public contact.

[See other documented chapter references](other-documented-chapters.md)

## Why verification matters

A team name, event label, social-media mention, or photograph does not automatically establish a formal chapter. The public directory only promotes a name to a full chapter profile when enough information exists to support it responsibly.

If your chapter can provide an approved name, founding date, charter or council reference, public officers, official link, history, and archive materials, those records can be reviewed for inclusion.

[Submit a chapter record](../corrections/index.md)
