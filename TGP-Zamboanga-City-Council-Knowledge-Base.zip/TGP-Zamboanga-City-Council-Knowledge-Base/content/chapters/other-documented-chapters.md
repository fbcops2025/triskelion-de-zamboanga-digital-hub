---
title: "Other Documented Chapter References"
slug: "/chapters/documented-references/"
seo_title: "Documented Tau Gamma Phi Chapter References in Zamboanga City"
meta_description: "See other Tau Gamma Phi chapter and community names documented in Zamboanga City Council material that still need registry confirmation."
primary_intent: "Other Tau Gamma Phi chapters in Zamboanga City"
status: "research-only-until-confirmed"
---

# Other Documented Chapter References

The research baseline contains additional chapter or community names that should remain in a **verification queue** until their formal status, spelling, founding record, and council relationship are confirmed.

Documented names include:

- Triskelion de Wesmincom
- Armor Village
- Morning Breeze
- Culianan
- Southcom
- Canelar Moret
- Estrada
- Main Road Divisoria
- Universidad de Zamboanga
- Gen. Tinio
- Gen. Concepcion

Names such as **Sta. Cruz, Guiwan, Putik, San Roque, Motorpool, and Cawa-Cawa** should not be published as formal chapters solely because they appeared as sports-team labels in available material.

## How a record becomes a full chapter profile

A strong chapter profile should ideally include a formal or council-recognized name, location, establishment date, source, chapter status, public officer information where approved, official page, historical milestones, service records, and photographs or documents with clear provenance.

[Submit a chapter record](../corrections/index.md)
