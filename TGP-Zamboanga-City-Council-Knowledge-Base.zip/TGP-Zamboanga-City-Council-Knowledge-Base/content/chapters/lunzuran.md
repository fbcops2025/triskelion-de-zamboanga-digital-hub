---
title: "Lunzuran Chapter"
slug: "/chapters/lunzuran/"
seo_title: "Lunzuran Chapter | Tau Gamma Phi Zamboanga City"
meta_description: "View the developing public record for Tau Gamma Phi's Lunzuran Chapter in Zamboanga City and the source requirements for its full chapter history."
primary_intent: "Tau Gamma Phi Lunzuran Chapter Zamboanga"
status: "needs-chapter-records"
---

# Lunzuran Chapter

Lunzuran Chapter appears in the Zamboanga City Council research record as a documented local chapter reference. Council material has also connected the chapter with Filipino boxer **Eumir Marcial**.

## Building a complete chapter history

The public archive still needs the chapter's founding date, charter or formal establishment record, early officers, current public leadership, official social channel, and approved historical photographs.

Until those records are available, the website should avoid inventing a chapter origin story or repeating membership claims beyond what the source material directly supports.

[Return to Chapters](index.md) | [Submit a source or correction](../corrections/index.md)
