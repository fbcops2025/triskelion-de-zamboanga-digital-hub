---
title: "WMSU Mother Chapter"
slug: "/chapters/wmsu-mother-chapter/"
seo_title: "WMSU Mother Chapter | Tau Gamma Phi Zamboanga"
meta_description: "Read the developing public history of the WMSU Mother Chapter, an important part of the Tau Gamma Phi Zamboanga City Council historical record."
primary_intent: "WMSU Tau Gamma Phi Mother Chapter history"
status: "needs-primary-records"
---

# WMSU Mother Chapter

The **WMSU Mother Chapter** is one of the most important names in the developing public history of Tau Gamma Phi in Zamboanga City. Council historical material records **8 December 1978** as its establishment date at **Western Mindanao State University**.

## Why this chapter matters

The chapter is identified in council material as a “Mother Chapter,” making its early records especially important for understanding how the local fraternity network developed after the 1975 Zamboanga City Council account.

## What the archive still needs

The current research does not yet contain the chapter's original charter, full founding-officer list, early photographs, or a confirmed chronology of its first years. Those materials should be collected before a fuller historical narrative is published.

Useful additions include dated chapter documents, anniversary programs, photographs with names and dates, old officer rosters, and council-issued records that identify founding details.

[Contribute a historical record](../corrections/index.md) | [Return to Chapters](index.md)
