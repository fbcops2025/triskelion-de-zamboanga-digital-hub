---
title: "Notable Triskelions"
slug: "/notable-triskelions/"
seo_title: "Notable Triskelions Connected to Zamboanga City | TGP-ZCC"
meta_description: "Explore carefully sourced public profiles of notable Triskelions with a documented connection to Zamboanga City Council or local chapters."
primary_intent: "Notable Tau Gamma Phi members from Zamboanga"
status: "evidence-gated"
---

# Publicly Documented Triskelions

This section is intended for public figures whose **Tau Gamma Phi affiliation and Zamboanga connection can be supported by credible, retained evidence**. It should never become a rumor list or a gallery of people assumed to be members because of a photograph, hand sign, event appearance, shirt, tag, or friendship.

## What makes a profile publishable

A public profile should have enough evidence to support both parts of the entry:

1. Why the person is publicly notable.
2. What reliable source supports the Tau Gamma Phi or Zamboanga City Council connection being described.

Profiles should use narrow, factual language and should not imply political endorsement, organizational support, or a broader chapter relationship that the source does not establish.

## Current research queue

The master research contains leads involving sports, public service, and local public figures. These should be published individually only after the underlying council post, institutional record, or direct public statement has been preserved.

A stronger long-term format is an individual profile page containing biography, public significance, documented fraternity connection, local chapter or council connection where verified, source links, and correction history.

[View Sources & Verification](../sources/index.md) | [Submit supporting evidence](../corrections/index.md)
