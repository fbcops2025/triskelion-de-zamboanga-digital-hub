# Public Page Template

```yaml
---
title: "Human-readable page title"
slug: "/route/"
seo_title: "Primary Topic | Tau Gamma Phi Zamboanga City Council"
meta_description: "Specific description of what the visitor will find."
primary_intent: "One clear search/user intent"
status: "draft-for-council-review"
---
```

# H1 that answers the visitor's question

Opening paragraph: explain immediately what this page is about and why it matters.

## Context / story

Write the useful public explanation, not the research process.

## Main information

Use meaningful subsections, cards, a timeline, profiles, or archive items depending on the page.

## Why it matters / what happens next

Give the reader context and a relevant internal link.

## Sources & record notes

Keep this short. Link to the source registry or supporting records. Put detailed uncertainty in the research layer rather than filling the public page with evidence labels.
