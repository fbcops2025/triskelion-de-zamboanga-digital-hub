# Developer Handoff

## Two-layer content architecture

Do not render `MASTER-RESEARCH.md` directly as a public webpage.

Use:

- `/content/` as the editable public website copy layer.
- `/research/` and `MASTER-RESEARCH.md` as internal evidence and verification layers.

## Routing

Each public Markdown file contains frontmatter with a target slug. Preserve those slugs when implementing the website unless an approved redirect plan exists.

## Publication gate

Content statuses should support at least:

- draft
- needs verification
- verified
- approved
- published
- archived
- disputed

A page can contain good public copy while still being blocked from publication because one key record, current roster, contact detail, or media permission remains missing.

## Source handling

Store detailed source IDs and verification notes separately from the main body when possible. The public interface can expose a compact “Sources” or “Record notes” drawer.

## Reusable content collections

Use structured collections for people, leadership terms, chapters, events, projects, historical milestones, media assets, documents, sources, and corrections. Avoid copying the same fact manually across multiple Markdown pages.

## SEO

Generate canonical URLs, unique metadata, breadcrumbs, XML sitemap, and structured data only from approved content. Do not auto-create thin tag pages or thousands of indexable filters.

## Historical accuracy

Do not use AI to fill missing dates, biographies, chapter founders, membership, event outcomes, or officer terms. Missing information should remain missing until a source is added.
