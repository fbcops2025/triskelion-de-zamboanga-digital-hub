# Website Sitemap

```text
/                         Home
/about/                   About the Council
/history/                 Public history
/history/timeline/        Timeline
/leadership/              Current approved leadership
/leadership/archive/      Past leadership
/chapters/                Chapter directory
/chapters/{slug}/         Individual chapter pages
/service/                 Community service
/events/                  Events and public notices
/notable-triskelions/     Evidence-backed public profiles
/archive/                 Digital archive
/sources/                 Source and verification policy
/corrections/             Corrections and historical contributions
/contact/                 Verified public contact
```

## Navigation rule

Keep the top navigation short:

**Home | About | History | Chapters | Service | Events | Archive | More**

“More” can contain Leadership, Notable Triskelions, Sources, Corrections, and Contact.

This prevents the main navigation from becoming overloaded while keeping every important section reachable in one or two clicks.

## Page-length rule

If a page becomes too long, split it by user intent rather than arbitrary word count. Examples:

- History -> Timeline -> Decade pages
- Chapters -> Individual chapter pages
- Leadership -> Current -> Archive by year
- Service -> Blood Donation / Feeding / Environment / Relief
- Archive -> Photos / Documents / Videos / Anniversary Materials
