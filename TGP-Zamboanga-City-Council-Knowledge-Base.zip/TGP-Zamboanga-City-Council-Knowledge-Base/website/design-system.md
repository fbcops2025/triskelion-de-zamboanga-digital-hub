# Website Design Direction

## Visual idea

A **modern civic archive with fraternity heritage**, not a generic fraternity template.

The design should feel strong and established without becoming aggressive or overly ceremonial. History and service should be as visually important as the crest.

## Proposed palette

These are proposed website colors, not claimed official standards.

- Near Black: `#11161C`
- Archival Ivory: `#FFFDF7`
- Heritage Gold: `#C8A64B`
- Warm Neutral: `#E6D7B0`
- Alert / Correction Red: `#A63A3A`

## Layout

- Strong but restrained hero sections.
- Editorial typography for history pages.
- Clear sans-serif body text for readability.
- Timeline components for historical periods.
- Chapter cards with location/status information.
- Archive cards with date, caption, source, and rights status.
- Compact source drawers or “View sources” links rather than research notes interrupting the main copy.
- Mobile-first layouts with no long horizontal carousels required to access key information.

## Homepage visual hierarchy

1. Hero and identity
2. Why the site exists
3. History preview
4. Service and community impact
5. Chapters
6. Events/notices
7. Archive
8. Contribution/correction CTA

## Photography

Prefer authentic, rights-cleared historical and current council material. Do not use generic fraternity stock imagery when real local records are available.
