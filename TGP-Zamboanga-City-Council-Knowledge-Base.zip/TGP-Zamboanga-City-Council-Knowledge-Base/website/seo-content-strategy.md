# SEO and Content Strategy

## Principle

Search visibility should come from **useful public information**, not from repeating keywords. The best pages should be worth reading even if search engines did not exist.

## Primary search-intent map

| Page | Main intent | Natural topic cluster |
|---|---|---|
| Home | What/where is Tau Gamma Phi Zamboanga City Council? | Tau Gamma Phi Zamboanga, Triskelion Zamboanga |
| About | What is the Zamboanga City Council? | TGP Zamboanga City Council |
| History | What is the history of Tau Gamma Phi in Zamboanga? | Tau Gamma Phi Zamboanga history |
| Chapters | What chapters are documented in Zamboanga City? | Tau Gamma Phi chapters Zamboanga |
| Leadership | Who are the council officers? | TGP Zamboanga leadership |
| Service | What community service has been documented? | Triskelion community service Zamboanga |
| Events | What activities and anniversaries are documented? | Tau Gamma Phi Zamboanga events |
| Archive | Where can I find old records/photos? | Triskelion Zamboanga archive |
| Notable Triskelions | Which public figures have documented local ties? | notable Triskelions Zamboanga |

## Writing for search without sounding like SEO copy

Use the primary phrase in the SEO title, H1, opening paragraph, and where naturally relevant. Then write for the reader.

Bad:

> Tau Gamma Phi Zamboanga City Council is the Tau Gamma Phi Zamboanga page for Tau Gamma Phi Zamboanga history and chapters.

Better:

> The Zamboanga City Council digital archive brings together the public history, chapters, service projects, events, and records of Tau Gamma Phi in Zamboanga City.

## Content-depth rule

Do not create thin pages simply to target a keyword. A chapter page should exist when there is enough useful information to help a visitor. Until then, keep the name in the chapter directory or research queue.

## Internal linking

Important relationships should be connected naturally:

- A historical milestone links to the related chapter.
- A chapter page links to its documented service projects.
- An event links to its source or archive record.
- A public profile links to the chapter or local record only when the connection is verified.
- Archive items link back to the event, chapter, person, or timeline entry they support.

## Search-result copy

Meta descriptions should tell the searcher exactly what they can find on the page. Avoid marketing superlatives and unsupported claims such as “largest,” “official national,” “most trusted,” or “complete history.”

## Structured data

Use only when the public content supports it:

- `WebSite`
- `BreadcrumbList`
- `Organization` after formal council approval
- `Person` for publishable public profiles
- `Event` for verified public events
- `Article` for news/history features
- `ImageObject` for rights-cleared archive media

## Evergreen + current content

The site should combine:

- **Evergreen:** history, chapters, archive, source methodology.
- **Current:** public notices, upcoming events, current leadership.
- **Growing archive:** newly verified photos, documents, projects, and historical corrections.

This keeps the website useful even when no new event is happening.
